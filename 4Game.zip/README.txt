Please ensure that all the Java files are in the same package.
The board is cloned after initial creation and every move will show a new board with new moves taken into account.